#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
	pid_t pid;
	int status;
pid = fork();

switch(pid){

		case -1:
			printf("fork failed");
			break;
		case 0:
			printf("I am the child process %d \n" , pid);
			break;
		default:
			printf("I am the parent process %d \n" , pid);
			pid = wait(&status);
			printf("The parent is done \n");
			pid = wait(&status);
			printf("The child is done \n");

	}
	return 0;
}
